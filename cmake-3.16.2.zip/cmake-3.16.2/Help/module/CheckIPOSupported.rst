.. cmake-module:: ../../Modules/CheckIPOSupported.cmake
