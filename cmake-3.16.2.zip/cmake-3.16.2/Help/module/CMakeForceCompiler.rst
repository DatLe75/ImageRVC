.. cmake-module:: ../../Modules/CMakeForceCompiler.cmake
